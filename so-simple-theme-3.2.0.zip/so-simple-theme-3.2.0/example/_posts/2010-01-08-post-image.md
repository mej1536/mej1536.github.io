---
title: "Post: Image"
image: /images/so-simple-sample-image-3.jpg
categories:
  - Post Formats
tags:
  - content
  - image
last_modified_at: 2019-01-08T08:50:52-05:00
---

This post should display a large image at the top of a page.

```yaml
image: /images/so-simple-sample-image-3.jpg
```

Tall images will push content down the page. `1600 x 600` is a good middle-ground size to aim for.
